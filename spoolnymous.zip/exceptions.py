class ApplicationError(Exception):
    """Exception générique pour tout le projet."""
    pass